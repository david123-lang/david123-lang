package com.example.quiz.adapter;

import android.content.Context;
import android.content.Intent;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.LinearLayout;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.example.quiz.MainActivity;
import com.example.quiz.R;
import com.example.quiz.Register;
import com.example.quiz.Warehouse.eventDataWarehouse;
import com.example.quiz.eventDetail;
import com.example.quiz.model.Event;

import java.util.ArrayList;
import java.util.zip.Inflater;

public class eventAdapter extends RecyclerView.Adapter<eventAdapter.ViewHolder> {

    private ArrayList<Event> eventList;
    private Context context;
    private View view;
    private LayoutInflater inf;

    public eventAdapter(Context context, ArrayList<Event> eventList) {
        inf = LayoutInflater.from(context);

        this.eventList = eventList;
        this.context = context;
    }

    @NonNull
    @Override
    public ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {

        view = inf.inflate(R.layout.activity_item_list, parent, false);
        return new ViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull ViewHolder holder, int position) {

        holder.eventNameTextView.setText(eventList.get(position).getEventName());
        holder.eventDateTextView.setText(eventList.get(position).getEventTime());

        holder.linearLayout.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(context, eventDetail.class);
                intent.putExtra("eventName", eventList.get(position).getEventName());
                intent.putExtra("eventTime", eventList.get(position).getEventTime());
                intent.putExtra("eventOrganizer", eventDataWarehouse.events.get(position).getEventOrganizer());
                intent.putExtra("eventDescription", eventDataWarehouse.events.get(position).getEventDetail());
                context.startActivity(intent);
            }
        });
    }

    @Override
    public int getItemCount() {

        return eventList.size();
    }

    public class ViewHolder extends RecyclerView.ViewHolder {

        private TextView eventNameTextView;
        private TextView eventDateTextView;
        private LinearLayout linearLayout;

        public ViewHolder(@NonNull View itemView) {
            super(itemView);

            eventNameTextView = itemView.findViewById(R.id.TV_eventName);
            eventDateTextView = itemView.findViewById(R.id.TV_eventDate);

            linearLayout = itemView.findViewById(R.id.LL_ItemList);

        }

    }
}

