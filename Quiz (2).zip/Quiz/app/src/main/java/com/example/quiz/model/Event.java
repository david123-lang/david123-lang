package com.example.quiz.model;

public class Event {
    public String eventID, eventOrganizer ,eventName, eventTime, eventDetail;

    public Event(String eventID, String eventOrganizer, String eventName, String eventTime, String eventDetail) {
        this.eventID = eventID;
        this.eventOrganizer = eventOrganizer;
        this.eventName = eventName;
        this.eventTime = eventTime;
        this.eventDetail = eventDetail;
    }

    public String getEventID() {
        return eventID;
    }

    public void setEventID(String eventID) {
        this.eventID = eventID;
    }

    public String getEventOrganizer() {
        return eventOrganizer;
    }

    public void setEventOrganizer(String eventOrganizer) {
        this.eventOrganizer = eventOrganizer;
    }

    public String getEventName() {
        return eventName;
    }

    public void setEventName(String eventName) {
        this.eventName = eventName;
    }

    public String getEventTime() {
        return eventTime;
    }

    public void setEventTime(String eventTime) {
        this.eventTime = eventTime;
    }

    public String getEventDetail() {
        return eventDetail;
    }

    public void setEventDetail(String eventDetail) {
        this.eventDetail = eventDetail;
    }
}


