package com.example.quiz;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import com.example.quiz.Warehouse.userDataWarehouse;
import com.example.quiz.model.Users;

import java.util.Vector;

public class MainActivity extends AppCompatActivity {

    private EditText userName, password;
    private Button loginBTN, registerBTN;
    public static Vector<String> vUserID = new Vector<>();

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        userName = findViewById(R.id.et_Username);
        password = findViewById(R.id.et_Password);
        loginBTN = findViewById(R.id.btn_Log);
        registerBTN = findViewById(R.id.btn_reg);

        String[] iduser = getResources().getStringArray(R.array.id);
        String[] usern = getResources().getStringArray(R.array.name);
        String[] passwor = getResources().getStringArray(R.array.passw);
        String[] email = getResources().getStringArray(R.array.email);
        String[] telp = getResources().getStringArray(R.array.notelp);

        userDataWarehouse.init(iduser, usern, passwor, email, telp);
        userDataWarehouse.duplicate = true;

        loginBTN.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                boolean checkaccount = false;

                String named = userName.getText().toString();
                String pass = password.getText().toString();

                for (Users userData : userDataWarehouse.user) {

                    if (named.isEmpty()) {
                        Toast.makeText(MainActivity.this, "Please Fill Username!", Toast.LENGTH_SHORT).show();
                        break;

                    } else if (pass.isEmpty()) {
                        Toast.makeText(MainActivity.this, "Please Fill Password!", Toast.LENGTH_SHORT).show();
                        break;

                    } else if (!userData.getUsername().equals(named)) {
                        checkaccount = true;

                    } else if (!userData.getPassword().equals(pass)) {
                        checkaccount = true;

                    } else {
                        idStorage.setUserID(userData.getUserID());

                        Toast.makeText(MainActivity.this, "Login Success!", Toast.LENGTH_SHORT).show();

                        Intent intent = new Intent(MainActivity.this, MainForm.class);
                        startActivity(intent);
                    }
                }

                if(checkaccount == true){
                    Toast.makeText(MainActivity.this, "Account is not Registered!", Toast.LENGTH_SHORT).show();
                }
            }
        });

        registerBTN.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                Intent intent = new Intent(MainActivity.this, Register.class);
                startActivity(intent);
            }
        });
    }
}