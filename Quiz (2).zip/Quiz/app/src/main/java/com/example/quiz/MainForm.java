package com.example.quiz;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;

public class MainForm extends AppCompatActivity {

    private Button createEventBTN, eventListBTN, logoutBTN, sendMessageBTN;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main_form);

        createEventBTN = findViewById(R.id.BTN_createEvent);
        eventListBTN = findViewById(R.id.BTN_eventList);
        logoutBTN = findViewById(R.id.BTN_logout);
        sendMessageBTN = findViewById(R.id.BTN_sendMessage);

        createEventBTN.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                Intent intent = new Intent(MainForm.this, createEventForm.class);
                startActivity(intent);

            }
        });

        eventListBTN.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                Intent intent = new Intent(MainForm.this, eventList.class);
                startActivity(intent);

            }
        });

        sendMessageBTN.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                Intent intent = new Intent(MainForm.this, sendMessage.class);
                startActivity(intent);

            }
        });

        logoutBTN.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                Intent intent = new Intent(MainForm.this, MainActivity.class);
                startActivity(intent);

            }
        });

    }
}