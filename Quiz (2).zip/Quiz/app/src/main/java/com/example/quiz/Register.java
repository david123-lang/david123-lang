package com.example.quiz;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import com.example.quiz.Warehouse.userDataWarehouse;
import com.example.quiz.model.Users;

import java.util.Random;

public class Register extends AppCompatActivity {

    private EditText newUsername, newPassword, rePassword, phoneNumber, email;
    private Button registerBTN;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_register);

        newUsername = findViewById(R.id.et_newUsername);
        newPassword = findViewById(R.id.et_newPassword);
        phoneNumber = findViewById(R.id.et_phoneNumber);
        rePassword = findViewById(R.id.et_rePassword);
        email = findViewById(R.id.et_Email);
        registerBTN = findViewById(R.id.btn_register);

        registerBTN.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                String newName = newUsername.getText().toString();
                String newPass = newPassword.getText().toString();
                String noPhone = phoneNumber.getText().toString();
                String confPass = rePassword.getText().toString();
                String mail = email.getText().toString();

                char[] data = newPass.toCharArray();

                boolean checkdigit = true;
                boolean checkupper = true;
                boolean checklower = true;
                boolean checknumber = true;

                for (char c : data){
                    if (Character.isDigit(c)){
                        checkdigit = false;
                    }
                }

                for (char c : data){
                    if (Character.isUpperCase(c)){
                        checkupper = false;
                    }
                }

                for (char c : data){
                    if (Character.isLowerCase(c)){
                        checklower = false;
                    }
                }

                for (char c : data){
                    if (Character.isDigit(c)){
                        checknumber = false;
                    }
                }

                if (newName.length() < 5 || newName.length() > 30) {
                    Toast.makeText(Register.this, "Username Must Between 5 and 30 Characters!", Toast.LENGTH_SHORT).show();
                } else if (newPass.length() < 6) {
                    Toast.makeText(Register.this, "Password Must More Than 6 Characters!", Toast.LENGTH_SHORT).show();
                } else if (checkupper) {
                    Toast.makeText(Register.this, "upper", Toast.LENGTH_SHORT).show();
                } else if (checklower) {
                    Toast.makeText(Register.this, "lower", Toast.LENGTH_SHORT).show();
                } else if (checkdigit){
                    Toast.makeText(Register.this, "digit", Toast.LENGTH_SHORT).show();
                } else if (noPhone.length() < 10 || noPhone.length() > 12) {
                    Toast.makeText(Register.this, "Phone Number Must Between 10 and 12 Numbers!", Toast.LENGTH_SHORT).show();
                } else if (checknumber){
                    Toast.makeText(Register.this, "Phone Number Must Number!", Toast.LENGTH_SHORT).show();
                } else if(!confPass.equals(newPass)){
                    Toast.makeText(Register.this, "Invalid Re-Password!", Toast.LENGTH_SHORT).show();
                } else if(mail.startsWith("@") || mail.endsWith("@")){
                    Toast.makeText(Register.this, "Invalid Email!", Toast.LENGTH_SHORT).show();
                } else if(!mail.contains(".")){
                    Toast.makeText(Register.this, "Invalid Email!", Toast.LENGTH_SHORT).show();
                } else if(mail.contains("@.") || mail.contains("@.")){
                    Toast.makeText(Register.this, "Invalid Email!", Toast.LENGTH_SHORT).show();
                } else {

                    Random random = new Random();
                    int rNumber = random.nextInt(1000 + 1 - 1) + 1;

                    String ID = String.format("US%03d", rNumber);

                    Toast.makeText(Register.this, "Registration Success!", Toast.LENGTH_SHORT).show();

                    Users store = new Users();
                    store.userID = ID;
                    store.username = newName;
                    store.password = newPass;
                    store.email = mail;
                    store.phoneNumber = noPhone;
                    userDataWarehouse.user.add(store);

                    Intent intent = new Intent(Register.this, MainActivity.class);
                    startActivity(intent);
                }
            }
        });
    }
}



