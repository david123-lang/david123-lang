package com.example.quiz;

import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;

import android.Manifest;
import android.app.Activity;
import android.app.PendingIntent;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.content.pm.PackageManager;
import android.os.Bundle;
import android.telephony.SmsManager;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

public class sendMessage extends AppCompatActivity {

    private EditText messageET, destinedNumberET;
    private Button sendBTN;
    private SmsManager smsManager;
    private PendingIntent sendMessagePI, deliveredMessagePI;

    int messagePermission;
    String sendMessageStatus, deliveredMessageStatus;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_send_message);

        messageET = findViewById(R.id.et_Message);
        destinedNumberET = findViewById(R.id.et_destinedPhoneNumber);
        sendBTN = findViewById(R.id.btn_sendMessageOrganizer);
        smsManager = SmsManager.getDefault();

        messagePermission = ContextCompat.checkSelfPermission(this, Manifest.permission.SEND_SMS);

        if(messagePermission != PackageManager.PERMISSION_GRANTED){
            ActivityCompat.requestPermissions(this, new String[]{Manifest.permission.SEND_SMS}, 1);
        }

        sendMessageStatus = "SMS_SENT";
        sendMessagePI = PendingIntent.getBroadcast(this, 0, new Intent(sendMessageStatus), 0);

        registerReceiver(new BroadcastReceiver() {
            @Override
            public void onReceive(Context arg0, Intent arg1) {
                switch (getResultCode()){
                    case Activity.RESULT_OK:
                        Toast.makeText(getBaseContext(), "Your Message Successfully Send", Toast.LENGTH_SHORT).show();
                        break;
                    case SmsManager.RESULT_ERROR_GENERIC_FAILURE:
                        Toast.makeText(getBaseContext(), "Your Message Not Send", Toast.LENGTH_SHORT).show();
                        break;
                }
            }
        } ,new IntentFilter(sendMessageStatus));

        sendBTN.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String messageText = messageET.getText().toString();
                String destinedNumberText = destinedNumberET.getText().toString();

                char[] number = destinedNumberText.toCharArray();

                boolean checknumber = true;

                for (char c : number){
                    if (Character.isDigit(c)){
                        checknumber = false;
                    }
                }

                if(messageText.isEmpty()){
                    Toast.makeText(sendMessage.this, "Message is Empty", Toast.LENGTH_SHORT).show();
                }else if(messageText.length() > 160){
                    Toast.makeText(sendMessage.this, "Message more than 160 characters", Toast.LENGTH_SHORT).show();
                }else if(destinedNumberText.length() < 10 || destinedNumberText.length() > 12) {
                    Toast.makeText(sendMessage.this, "Phone Number Must Between 10 and 12 Numbers", Toast.LENGTH_SHORT).show();
                }else if(checknumber){
                    Toast.makeText(sendMessage.this, "Phone Number Must Only Contain Numbers", Toast.LENGTH_SHORT).show();
                }else{

                    smsManager.sendTextMessage(destinedNumberText, null, messageText, sendMessagePI, null);

                    Intent intent = new Intent(sendMessage.this, MainForm.class);
                    startActivity(intent);
                }
            }
        });

    }
}