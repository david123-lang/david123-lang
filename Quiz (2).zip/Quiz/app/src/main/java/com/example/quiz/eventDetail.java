package com.example.quiz;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;

import com.example.quiz.Warehouse.eventDataWarehouse;
import com.example.quiz.model.Event;

public class eventDetail extends AppCompatActivity {

    TextView nameDetail, timeDetail, organizerDetail, descriptionDetail;
    Button Deletebtn, Editbtn;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_event_detail);

        nameDetail = findViewById(R.id.TV_eventNameDetail);
        timeDetail = findViewById(R.id.TV_eventTimeDetails);
        organizerDetail = findViewById(R.id.TV_eventOrganizerDetail);
        descriptionDetail = findViewById(R.id.TV_eventDetail);

        Editbtn = findViewById(R.id.BTN_Edit);
        Deletebtn = findViewById(R.id.BTN_Delete);

        nameDetail.setText(getIntent().getStringExtra("eventName"));
        timeDetail.setText(getIntent().getStringExtra("eventTime"));
        organizerDetail.setText(getIntent().getStringExtra("eventOrganizer"));
        descriptionDetail.setText(getIntent().getStringExtra("eventDescription"));

        Editbtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(eventDetail.this, editEvent.class);
                startActivity(intent);
            }
        });

        Deletebtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

            }
        });

    }
}