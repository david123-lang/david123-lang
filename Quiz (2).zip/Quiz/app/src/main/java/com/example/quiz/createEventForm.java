package com.example.quiz;

import androidx.appcompat.app.AppCompatActivity;
import androidx.fragment.app.DialogFragment;

import android.app.DatePickerDialog;
import android.app.TimePickerDialog;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.DatePicker;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.TimePicker;
import android.widget.Toast;

import com.example.quiz.Warehouse.eventDataWarehouse;
import com.example.quiz.fragment.datePickerFragment;
import com.example.quiz.fragment.timePickerFragment;

import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.Random;

public class createEventForm extends AppCompatActivity implements DatePickerDialog.OnDateSetListener, TimePickerDialog.OnTimeSetListener {

    private TextView eventDateTextView, eventTimeTextView;
    private EditText eventNameTextView, eventDetailsTextView;
    private Button datePickerBTN, timePickerBTN, createEventBTN;
    private SimpleDateFormat dateFormat;
    String monthName, menit;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_create_event_form);

        eventDateTextView = findViewById(R.id.TV_eventDate);
        datePickerBTN = findViewById(R.id.btn_pickDate);

        eventTimeTextView = findViewById(R.id.TV_eventTime);
        timePickerBTN = findViewById(R.id.btn_pickTime);

        createEventBTN = findViewById(R.id.createEvent_btn);
        eventNameTextView = findViewById(R.id.et_eventName);
        eventDetailsTextView = findViewById(R.id.et_eventDetails);

        String[] evId = getResources().getStringArray(R.array.eventID);
        String[] orId = getResources().getStringArray(R.array.organizerID);
        String[] details = getResources().getStringArray(R.array.eventDetails);

        eventDataWarehouse.duplicate = true;

        datePickerBTN.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                DialogFragment dialogFragment = new datePickerFragment();
                dialogFragment.show(getSupportFragmentManager(),"Date Picker");
            }
        });

        timePickerBTN.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                DialogFragment dialogFragment = new timePickerFragment();
                dialogFragment.show(getSupportFragmentManager(), "Time Picker");
            }
        });

        createEventBTN.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                String nameEvent = eventNameTextView.getText().toString();
                String detailEvent = eventDetailsTextView.getText().toString();

                String dateEvent = eventDateTextView.getText().toString();
                String watchEvent = eventTimeTextView.getText().toString();
                String timeEvent = eventDateTextView.getText().toString() + " " + eventTimeTextView.getText().toString();

                String idOrganizer = idStorage.getUserID();

                if(nameEvent.isEmpty()){
                    Toast.makeText(createEventForm.this, "Event Name is Empty!", Toast.LENGTH_SHORT).show();
                }else if(detailEvent.isEmpty()) {
                    Toast.makeText(createEventForm.this, "Event Details is Empty!", Toast.LENGTH_SHORT).show();
                }else if(dateEvent.equals("Choose Event Date!")){
                    Toast.makeText(createEventForm.this, "Must Choose Event Date", Toast.LENGTH_SHORT).show();
                }else if(watchEvent.equals("Choose Event Time!")) {
                    Toast.makeText(createEventForm.this, "Must Choose Event Time", Toast.LENGTH_SHORT).show();
                }else {

                    Random random = new Random();
                    int rNumber = random.nextInt(1000 + 1 - 1) + 1;

                    String ID = String.format("US%03d", rNumber);

                    Toast.makeText(createEventForm.this, "Create New Event Success", Toast.LENGTH_SHORT).show();

                    Intent intent = new Intent(createEventForm.this, MainForm.class);
                    startActivity(intent);
                    finish();
                }
            }
        });
    }

    @Override
    public void onDateSet(DatePicker view, int year, int month, int day) {
            eventDateTextView.setText((month+1) + "/" +day+ "/" + year);
        }

    @Override
    public void onTimeSet(TimePicker view, int hour, int minute) {

        if(minute >= 0 && minute <= 9){
            menit = "0" + minute;
            eventTimeTextView.setText(hour + ":" + menit);
        }else if(minute > 9){
            eventTimeTextView.setText(hour + ":" + minute);
        }
    }

}


