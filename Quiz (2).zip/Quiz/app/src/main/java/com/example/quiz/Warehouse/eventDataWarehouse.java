package com.example.quiz.Warehouse;

import com.example.quiz.model.Event;

import java.util.ArrayList;

public class eventDataWarehouse {
    public static ArrayList<Event> events = new ArrayList<>();
    public static boolean duplicate = false;

    public static void init(){
        events.add(new Event("EV989", "US996", "Fibrodyne", "11/23/2020 16:00",
                "Non exercitation sint pariatur fugiat irure nostrud adipisicing eiusmod pariatur commodo eiusmod non labore."));
        events.add(new Event("EV990", "US996", "Biotica", "11/25/2020 13:00",
                "Deserunt proident sint ad cillum velit eu amet proident est nostrud occaecat voluptate in. Anim fugiat consequat " +
                        "ullamco aliqua amet do culpa magna fugiat. Laboris deserunt amet anim veniam incididunt fugiat voluptate commodo in in"));
        events.add(new Event("EV991", "US997", "Oatfarm", "1/1/2021 9:00","Occaecat aliquip exercitation deserunt mollit " +
                "aliqua nisi laboris. Qui Lorem nostrud esse mollit magna sunt aliquip qui. Nostrud quis incididunt cillum ex nulla aute sunt voluptate ad laborum ipsum cupidatat veniam."));
        events.add(new Event("EV992", "US997", "Isonus", "1/3/2021 15:00","Eiusmod labore aliqua culpa laboris occaecat sunt " +
                "nulla dolore velit excepteur anim. Tempor occaecat ullamco eiusmod Lorem veniam voluptate."));
        events.add(new Event("EV993", "US998", "Comtrek", "1/3/2021 14:00","Sunt incididunt duis fugiat " +
                "ipsum pariatur ipsum. Officia duis cupidatat laborum quis reprehenderit cillum consectetur labore commodo consectetur."));
        events.add(new Event("EV994", "US998", "Sentia", "1/4/2021 16:00","Veniam consectetur enim nulla ea esse culpa ut minim " +
                "exercitation non non. Aliquip qui Lorem duis veniam amet cillum consectetur esse Lorem culpa eu adipisicing culpa et."));
        events.add(new Event("EV995", "US999", "Opportech", "1/5/2021 14:00","Nisi aliqua sint adipisicing velit. Ipsum officia irure excepteur " +
                "id est ea aliquip Lorem commodo enim deserunt adipisicing."));
        events.add(new Event("EV996", "US999", "Digitalus", "1//2021 10:00","Minim quis laboris anim laborum esse culpa adipisicing est culpa aute ea duis. incididunt duis id consequat. "));
        events.add(new Event("EV997", "US999", "Calcu", "1/6/2021 17:00","Voluptate velit ex sint in anim aute nulla ad aute. Ex exercitation occaecat fugiat cupidatat consectetur."));
        events.add(new Event("EV998", "US999", "Norsup", "1/7/2021 14:00","Occaecat cillum laboris sunt laborum minim qui aliqua. Officia reprehenderit nisi veniam mollit occaecat. " +
                "Occaecat voluptate qui amet irure."));
    }

    public static ArrayList<Event> getEvents() {
        return events;
    }

}
