package com.example.quiz.Warehouse;

import com.example.quiz.model.Users;

import java.util.ArrayList;

public class userDataWarehouse {

    public static ArrayList <Users> user = new ArrayList<>();
    public static boolean duplicate = false;

    public static void init(String[] id, String[] name, String[] pass, String[] email, String[] notelp){

        if(duplicate == true){
            return;
        }

        for(int i = 0; i < id.length; i++){
            Users store = new Users();
            store.userID = id[i];
            store.username = name[i];
            store.password = pass[i];
            store.email = email[i];
            store.phoneNumber = notelp[i];
            user.add(store);
        }
    }

    public static ArrayList<Users> getUser() {
        return user;
    }
}
