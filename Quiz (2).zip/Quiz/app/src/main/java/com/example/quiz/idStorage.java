package com.example.quiz;

public class idStorage {
    private static String UserID;

    public static String getUserID() {
        return UserID;
    }

    public static void setUserID(String userID) {
        UserID = userID;
    }
}
