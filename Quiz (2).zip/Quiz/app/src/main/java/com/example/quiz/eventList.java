package com.example.quiz;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.DividerItemDecoration;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.os.Bundle;

import com.example.quiz.Warehouse.eventDataWarehouse;
import com.example.quiz.adapter.eventAdapter;

public class eventList extends AppCompatActivity {

    private eventAdapter A_event;
    private RecyclerView recyclerView;
    private boolean duplicateData = false;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_event_list);

        recyclerView = findViewById(R.id.RV_eventList);

        eventDataWarehouse.init();

        A_event = new eventAdapter(this, eventDataWarehouse.getEvents());

        recyclerView.setAdapter(A_event);
        recyclerView.addItemDecoration(new DividerItemDecoration(this, LinearLayoutManager.VERTICAL));
        recyclerView.setLayoutManager(new LinearLayoutManager(this));

    }
}